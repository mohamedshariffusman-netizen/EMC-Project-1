The pages load real construction photos from Unsplash (free licence). If you are offline, or a photo fails to load, the SVG illustrations in this folder are shown instead.
To use your own photos, edit the img src in the HTML files.
